import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";
import { ConfidentialClientApplication } from "msal-node";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

function env(key, fallback = undefined) {
  return process.env[key] ?? fallback;
}

function jsonTryParse(s, fallback = {}) {
  if (!s) return fallback;
  try { return JSON.parse(s); } catch { return fallback; }
}

// Central + Department overrides
function getDeptConfig(scope, dept) {
  const cfg = jsonTryParse(env("DEPARTMENT_CONFIG_JSON", ""));
  const out = {};
  if (cfg.central && typeof cfg.central === "object") Object.assign(out, cfg.central);
  if (scope === "department" && cfg[dept] && typeof cfg[dept] === "object") Object.assign(out, cfg[dept]);
  return out;
}

function resolveTarget(scope, dept) {
  const o = getDeptConfig(scope, dept);
  return {
    DATAHUB_GQL_ENDPOINT: o.DATAHUB_GQL_ENDPOINT || env("DATAHUB_GQL_ENDPOINT"),
    DATAHUB_TOKEN: o.DATAHUB_TOKEN || env("DATAHUB_TOKEN"),
    DATAHUB_QUERY: o.DATAHUB_QUERY || env("DATAHUB_QUERY", "*"),

    PBI_TENANT_ID: o.PBI_TENANT_ID || env("PBI_TENANT_ID"),
    PBI_CLIENT_ID: o.PBI_CLIENT_ID || env("PBI_CLIENT_ID"),
    PBI_CLIENT_SECRET: o.PBI_CLIENT_SECRET || env("PBI_CLIENT_SECRET"),
    PBI_GROUP_ID: o.PBI_GROUP_ID || env("PBI_GROUP_ID"),
    PBI_DATASET_ID: o.PBI_DATASET_ID || env("PBI_DATASET_ID"),
    PBI_REPORT_ID: o.PBI_REPORT_ID || env("PBI_REPORT_ID")
  };
}

// Mock fallback (so UI still works before wiring)
const MOCK = {
  datasets: [
    {
      id: "gold_unfip_funding",
      name: "UNFIP Funding & Disbursements (Gold)",
      domain: "Funding",
      sensitivity: "Internal",
      certified: true,
      owner: "UNOP / UNFIP – Finance & Analytics",
      updateCadence: "Monthly",
      freshnessSlaHours: 168,
      description: "Curated disbursement facts and breakdowns (grants vs. UN system entities), with partner and theme tags.",
      tables: ["fact_unfip_disbursements", "dim_implementing_partner", "dim_theme", "dim_country", "dim_date"],
      tags: ["Funding", "Donor", "Gold", "Certified"]
    }
  ],
  kpis: [
    {
      id: "kpi_unfip_total_disbursed",
      name: "UNFIP Total Disbursed (USD)",
      domain: "Funding",
      description: "Total UNFIP disbursements in the selected period.",
      formula: "SUM(disbursed_amount_usd)",
      owner: "Finance & Analytics",
      cadence: "Monthly",
      qualityChecks: ["No negative disbursements", "FX normalization applied", "Partner IDs valid"]
    }
  ],
  metrics: {
    values: {
      totalDisbursedUsd: 23500000,
      projectsSupported: 720,
      countriesParticipating: 138,
      loungeInPerson: 2000,
      loungeRemote: 500000,
      advocatesMembers: 17,
      advocatesSocialReach: 23000000
    },
    fundingBreakdown: [
      { name: "Grants", value: 12700000 },
      { name: "UN system entities (fiduciary)", value: 10800000 }
    ],
    trend: [
      { x: "2020", disbursed_m: 18.4 },
      { x: "2021", disbursed_m: 20.2 },
      { x: "2022", disbursed_m: 22.1 },
      { x: "2023", disbursed_m: 21.6 },
      { x: "2024", disbursed_m: 23.5 }
    ],
    initiativeReach: [
      { initiative: "SDG Goals Lounge", in_person: 2000, remote: 500000 },
      { initiative: "Women Rise for All", in_person: 300, remote: 2300 },
      { initiative: "SDG Advocates", in_person: 17, remote: 23000000 }
    ]
  }
};

// DataHub GraphQL search
async function datahubSearchDatasets({ endpoint, token, query, start = 0, count = 50 }) {
  const gql = {
    query: `
      query search($input: SearchInput!) {
        search(input: $input) {
          searchResults {
            entity {
              urn
              ... on Dataset {
                properties { name description }
                domain { properties { name } }
                tags { tags { tag { properties { name } } } }
              }
            }
          }
        }
      }`,
    variables: { input: { type: "DATASET", query, start, count } }
  };

  const r = await axios.post(endpoint, gql, {
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    timeout: 30000
  });

  const results = r?.data?.data?.search?.searchResults ?? [];
  return results.map((item) => {
    const ds = item?.entity ?? {};
    const props = ds?.properties ?? {};
    const domain = ds?.domain?.properties?.name ?? "Unknown";
    const tags = (ds?.tags?.tags ?? []).map((t) => t?.tag?.properties?.name).filter(Boolean);
    return {
      id: ds?.urn ?? props?.name ?? "dataset",
      name: props?.name ?? ds?.urn ?? "Dataset",
      domain,
      sensitivity: "Internal",
      certified: true,
      owner: "Unassigned",
      updateCadence: "Unknown",
      freshnessSlaHours: 168,
      description: props?.description ?? "",
      tables: [],
      tags
    };
  });
}

// Power BI access token (service principal)
function pbiClient({ tenantId, clientId, clientSecret }) {
  const authority = `https://login.microsoftonline.com/${tenantId}`;
  return new ConfidentialClientApplication({ auth: { clientId, authority, clientSecret } });
}

async function pbiAccessToken({ tenantId, clientId, clientSecret }) {
  const client = pbiClient({ tenantId, clientId, clientSecret });
  const res = await client.acquireTokenByClientCredential({
    scopes: ["https://analysis.windows.net/powerbi/api/.default"]
  });
  if (!res?.accessToken) throw new Error("Failed to acquire Power BI access token.");
  return res.accessToken;
}

async function pbiExecuteDax({ accessToken, groupId, datasetId, dax }) {
  const url = `https://api.powerbi.com/v1.0/myorg/groups/${groupId}/datasets/${datasetId}/executeQueries`;
  const body = { queries: [{ query: dax }], serializerSettings: { includeNulls: true } };
  const r = await axios.post(url, body, {
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    timeout: 30000
  });
  return r.data;
}

function extractRowNumber(execRes, colName) {
  const row = execRes?.results?.[0]?.tables?.[0]?.rows?.[0] ?? {};
  const v = row?.[colName] ?? row?.[Object.keys(row)[0]];
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
}

// Routes
app.get("/health", (_req, res) => res.json({ ok: true }));

app.get("/api/catalog", async (req, res) => {
  const provider = String(req.query.provider ?? "datahub");
  const scope = String(req.query.scope ?? "central");
  const dept = String(req.query.dept ?? "central");
  try {
    if (provider !== "datahub") {
      return res.json({ datasets: MOCK.datasets, note: "Only datahub provider implemented in this backend." });
    }

    const t = resolveTarget(scope, dept);
    if (!t.DATAHUB_GQL_ENDPOINT || !t.DATAHUB_TOKEN) {
      return res.json({ datasets: MOCK.datasets, note: "Missing DATAHUB creds; returned mock datasets." });
    }

    const datasets = await datahubSearchDatasets({
      endpoint: t.DATAHUB_GQL_ENDPOINT,
      token: t.DATAHUB_TOKEN,
      query: t.DATAHUB_QUERY || "*",
      start: 0,
      count: 50
    });
    return res.json({ datasets });
  } catch (e) {
    return res.status(500).json({ error: String(e?.message ?? e) });
  }
});

app.get("/api/kpis", (_req, res) => {
  res.json({ kpis: MOCK.kpis });
});

app.get("/api/metrics/summary", async (req, res) => {
  const period = String(req.query.period ?? "y2024");
  const scope = String(req.query.scope ?? "central");
  const dept = String(req.query.dept ?? "central");
  try {
    const t = resolveTarget(scope, dept);
    const hasPbi = !!(t.PBI_TENANT_ID && t.PBI_CLIENT_ID && t.PBI_CLIENT_SECRET && t.PBI_GROUP_ID && t.PBI_DATASET_ID);
    if (!hasPbi) {
      return res.json({ ...MOCK.metrics, note: "Missing Power BI config; returned mock metrics." });
    }

    const accessToken = await pbiAccessToken({ tenantId: t.PBI_TENANT_ID, clientId: t.PBI_CLIENT_ID, clientSecret: t.PBI_CLIENT_SECRET });

    // Replace measure names with your exact measures
    const dax = {
      totalDisbursedUsd: 'EVALUATE ROW("totalDisbursedUsd", [Total Disbursed USD])',
      projectsSupported: 'EVALUATE ROW("projectsSupported", [Projects Supported])',
      countriesParticipating: 'EVALUATE ROW("countriesParticipating", [Countries Participating])',
      loungeInPerson: 'EVALUATE ROW("loungeInPerson", [SDG Lounge In-Person])',
      loungeRemote: 'EVALUATE ROW("loungeRemote", [SDG Lounge Remote])',
      advocatesMembers: 'EVALUATE ROW("advocatesMembers", [SDG Advocates Members])',
      advocatesSocialReach: 'EVALUATE ROW("advocatesSocialReach", [SDG Advocates Social Reach])'
    };

    const r1 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.totalDisbursedUsd });
    const r2 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.projectsSupported });
    const r3 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.countriesParticipating });
    const r4 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.loungeInPerson });
    const r5 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.loungeRemote });
    const r6 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.advocatesMembers });
    const r7 = await pbiExecuteDax({ accessToken, groupId: t.PBI_GROUP_ID, datasetId: t.PBI_DATASET_ID, dax: dax.advocatesSocialReach });

    const values = {
      totalDisbursedUsd: extractRowNumber(r1, "totalDisbursedUsd"),
      projectsSupported: extractRowNumber(r2, "projectsSupported"),
      countriesParticipating: extractRowNumber(r3, "countriesParticipating"),
      loungeInPerson: extractRowNumber(r4, "loungeInPerson"),
      loungeRemote: extractRowNumber(r5, "loungeRemote"),
      advocatesMembers: extractRowNumber(r6, "advocatesMembers"),
      advocatesSocialReach: extractRowNumber(r7, "advocatesSocialReach")
    };

    return res.json({
      values,
      fundingBreakdown: MOCK.metrics.fundingBreakdown,
      trend: MOCK.metrics.trend,
      initiativeReach: MOCK.metrics.initiativeReach,
      note: `KPI values live from Power BI; charts currently mock. period=${period} scope=${scope} dept=${dept}`
    });
  } catch (e) {
    return res.status(500).json({ error: String(e?.message ?? e) });
  }
});

app.post("/api/powerbi/embed-token", async (req, res) => {
  const scope = String(req.query.scope ?? "central");
  const dept = String(req.query.dept ?? "central");
  try {
    const { reportId, groupId } = req.body ?? {};
    const t = resolveTarget(scope, dept);

    if (!t.PBI_TENANT_ID || !t.PBI_CLIENT_ID || !t.PBI_CLIENT_SECRET) {
      return res.status(400).json({ error: "Missing Power BI service principal env vars." });
    }
    const gId = groupId || t.PBI_GROUP_ID;
    const rId = reportId || t.PBI_REPORT_ID;
    if (!gId || !rId) return res.status(400).json({ error: "Missing groupId/reportId (env or request body)." });

    const accessToken = await pbiAccessToken({ tenantId: t.PBI_TENANT_ID, clientId: t.PBI_CLIENT_ID, clientSecret: t.PBI_CLIENT_SECRET });

    // Get embedUrl
    const reportUrl = `https://api.powerbi.com/v1.0/myorg/groups/${gId}/reports/${rId}`;
    const reportRes = await axios.get(reportUrl, { headers: { Authorization: `Bearer ${accessToken}` }, timeout: 30000 });
    const embedUrl = reportRes?.data?.embedUrl;

    // Generate embed token (View)
    const genUrl = `https://api.powerbi.com/v1.0/myorg/groups/${gId}/reports/${rId}/GenerateToken`;
    const genRes = await axios.post(genUrl, { accessLevel: "View" }, {
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      timeout: 30000
    });

    return res.json({ embedUrl, accessToken: genRes?.data?.token, tokenExpiry: genRes?.data?.expiration });
  } catch (e) {
    return res.status(500).json({ error: String(e?.message ?? e) });
  }
});

const port = Number(env("PORT", 8787));
app.listen(port, () => console.log(`UN Data Portal backend listening on http://localhost:${port}`));
