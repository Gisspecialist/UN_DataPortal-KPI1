# UN Data Portal Backend (Node/Express)

Endpoints (matching the Canvas React UI):
- `GET /api/catalog?provider=datahub&scope=central|department&dept=<id>`
- `GET /api/kpis`
- `GET /api/metrics/summary?period=...&scope=...&dept=...`
- `POST /api/powerbi/embed-token?scope=...&dept=...`  body: `{ "reportId": "...", "groupId": "..." }`

## Run locally
```bash
npm install
cp .env.example .env
npm run dev
```

Server: http://localhost:8787

## Wire the React UI
Configure your React dev server to proxy `/api` to `http://localhost:8787`.

## Notes
- DataHub: calls GraphQL search and maps datasets to the UI's Dataset[] shape.
- KPIs: returns a starter KPI dictionary. Replace with your governed registry.
- Metrics: pulls KPI values from Power BI `executeQueries` (replace measure names). Charts are mock placeholders.
- Power BI Embedded: returns embedUrl + embed token. Use the Power BI JS SDK in the UI for full embedding + RLS.
